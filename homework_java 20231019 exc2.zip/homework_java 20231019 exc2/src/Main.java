import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        do {
            System.out.println("Введите первое число диапазона ");
            int n1 = scr.nextInt();
            System.out.println("Введите второе число диапазона ");
            int n2 = scr.nextInt();
            int min = Integer.min(n1,n2);
            int max = Integer.max(n1,n2);
            int sum = 0;
            for (int i = min; i <= max; i++) {
                if (i % 2 != 0) {
                    sum = sum + i;
                }
            }
            System.out.println(sum);
            System.out.println("Введите quit для остановки программы");
        } while (!"quit".equalsIgnoreCase(scr.next()));
    }
}



//Задание 2
//Используйте for для вычисления суммы.
//Используйте do-while для организации повторения программы.
//
//
//Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
// Программу повторять, пока пользователь не введёт «quit».